# Atonom

Lekka aplikacja edukacyjna, która buduje interaktywny model cząsteczki
z polskiej nazwy związku chemicznego.

## Uruchomienie

```bash
npm start
```

Następnie otwórz `http://localhost:4173`.

Można też od razu wskazać związek w adresie:

```text
http://localhost:4173/index.html?formula=2,2-dichloroetan
```

## Obsługiwane nazwy

- alkany, cykloalkany, alkeny i alkiny do 12 atomów węgla;
- konfiguracje geometryczne prostych alkenów, np. `cis-but-2-en`
  i `trans-1,2-dichloroeten`;
- alkohole, aldehydy, ketony, kwasy karboksylowe, estry i aminy;
- proste podstawniki alkilowe: metylo-, etylo-, propylo- i butylo-;
- podstawione pochodne benzenu, np. `1-chloro-2-fluorobenzen`;
- glicyna i alanina;
- popularne nazwy zwyczajowe, m.in. fenol, toluen, anilina, aceton,
  kwas octowy, woda, amoniak i dwutlenek węgla.

Parser akceptuje zarówno zapis systematyczny (`propan-2-ol`, `but-2-en`),
jak i częste warianty (`2-propanol`, `2-buten`, `propanol`).

Interfejs zawiera tryb jasny i ciemny, rozszerzone sterowanie modelem oraz
edytowalną paletę kolorów atomów i rzędów wiązań zapisywaną lokalnie
w przeglądarce.

## Testy

```bash
npm test
```

Model ma charakter edukacyjny. Nie rozróżnia stereoizomerów ani konformerów.
